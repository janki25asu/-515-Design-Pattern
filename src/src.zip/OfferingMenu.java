package src;

public class OfferingMenu {

    public void viewOffering() {
        System.out.println("View Offering");

    }

    public void markOffering() {
        System.out.println("Mark Offering");
    }

    public void submitOffering() {
        System.out.println("Submit Offering");
    }
}
