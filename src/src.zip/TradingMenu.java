package src;

public class TradingMenu {
    public void addTrading() {
        System.out.println("Add Trading");
    }
    public void viewTrading() {
        System.out.println("View Trading");
    }
}
