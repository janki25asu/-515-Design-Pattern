package src;

public class BuyerTradingMenu {
    public static void buyertradingMenu(){
        System.out.println("This is a Buyer Trading Menu");
    }
}
