package src;

public class SellerTradingMenu {

    public static void sellertradingMenu(){
        System.out.println("Called SellerTrading Menu");
    }
}

