package src;

public class Offering {
    int deal;
    public void setDeal(){
        this.deal=1;
        System.out.println("Set Deal");
    }
    public void viewOffering(){
        System.out.println("View Offering");
    }
    public void marketOffering(){
        System.out.println("Mark Offering");
    }
    public void submitOffering(){
        System.out.println("Submit Offering");
    }
}
