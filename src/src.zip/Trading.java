package src;

public class Trading extends Reminder {

    public void accept(NodeVisitor nodeVisitor) {
        System.out.println("Trading Reminder!!");
    }
}
